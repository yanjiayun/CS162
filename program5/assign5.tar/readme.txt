Program: program5.cpp

*Author: Jiayun Yan

Date: 06/09/2019

*Description: This is the assignment5, created a linked list and implement some functions.

Input: All the enter as required, the number user wanted to include, whether they want to include another one, whether they want to do this again and they want to sort ascending or descending.

Output: The sorted linked list, the prime and how many primes are in the list.

*If the required input is provided wrong, this time of try will end.

*I had finished push_front(), insert() and get_length(),but not call them.

*Extra credit: I had implemented sort_descending() using a recursive Selection Sort algorithm.
